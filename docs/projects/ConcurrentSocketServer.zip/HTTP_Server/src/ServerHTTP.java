import java.net.*;
import java.io.*;
import java.util.regex.*;
import java.util.concurrent.*;
import java.util.Date;


//Server with socket serving at max 3 people at a time
public class ServerHTTP {
	public static void main(String[] args) throws IOException{
		Executor executor = Executors.newFixedThreadPool(3);
		ServerSocket server = new ServerSocket(8082);
		System.out.println("Listening for connection on port 8082....");
		while (true) {
			executor.execute(new SimpleHTTPServer(server.accept()));
		}
	}

}


class SimpleHTTPServer  implements Runnable{
	Socket client;
	
	SimpleHTTPServer(Socket client) {
		this.client = client;
	}

	@Override
	public void run() {
		try {
			//Set up the client readers and writers. 
			InputStream in = client.getInputStream();
			InputStreamReader isr = new InputStreamReader(in, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			OutputStream out = client.getOutputStream();
			OutputStreamWriter osr = new OutputStreamWriter(out, "UTF-8");
			BufferedWriter bw = new BufferedWriter(osr);
			
//			//Read and console out request from client
//			String line = br.readLine();
//			while(!line.isEmpty()) {
//				System.out.println(line);
//				line = br.readLine();
//			}
//			
//			//Print to client
//			Date message = new Date();
//			String header = "HTTP/1/1 200 OK\r\n\r\n";
//			String httpResponse = header + message;
//			out.write(httpResponse.getBytes("UTF-8"));
////			bw.write(httpResponse, 0, httpResponse.length());
			
			
			//Reading request for text files
			String request1 = br.readLine();
			System.out.println("Request: " + request1);
			Matcher getRequest = Pattern.compile("GET /?(\\S*).*").matcher(request1);
			
			//Writing file request to client
			String message = "";
			String header = "HTTP/1.1 200 OK\r\n\r\n";
			String httpResponse = header + message;
			if(getRequest.matches()) {
				String request = getRequest.group(1);
				System.out.println("File to be sent: " + request);
				try {
					FileReader fr = new FileReader( request );
					BufferedReader bfr = new BufferedReader(fr);
					
					String fileData;
					while((fileData = bfr.readLine()) != null) {
						message = message + "\n" + fileData;
					}
					fr.close();
					httpResponse = header + message;
					out.write(httpResponse.getBytes("UTF-8"));
					
				} catch (FileNotFoundException e) {
					httpResponse = header + "404 Object not found";
					out.write(httpResponse.getBytes("UTF-8"));
				}
				
			} else {
				httpResponse = header + "400 Bad Request";
				out.write(httpResponse.getBytes("UTF-8"));
			}
			
			//Close client session
			client.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}

			
	}
		
	
	
}









//
//
//
//
//class TinyHttpdConnection implements Runnable {
//	Socket client;
//	
//	TinyHttpdConnection(Socket client) {
//		this.client = client;
//	}
//	
//	@Override
//	public void run() {
//		try {
//			// Set streams for client connection. Buffer in and print out
//			BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream(), "8859_1"));
//			OutputStream out = client.getOutputStream();
//			PrintWriter pout = new PrintWriter(new OutputStreamWriter(out, "8859_1"), true);
//			pout.println("HTTP/1.1 200 OK \r\n\r\n Printing something to the client");
//			
//			
//			
////			// Read request and print request to screen. Match pattern
////			String request = br.readLine();
////			System.out.println("Request: " + request);
////			Matcher get = Pattern.compile("GET /?(\\S*).*").matcher(request);
////			
////			if(get.matches()) {
////				System.out.println("There is a match!");
////			}
//			
////			//If there is a request, send file to client. Print if error
////			if(get.matches()) {
////				request = get.group(1);
////				if ( request.endsWith("?") || request.equals("") )
////					request = request + "index.html";
////				try {
////					FileInputStream fin = new FileInputStream( request );
////					byte[] data = new byte[64*1024];
////					for (int read ; (read = fin.read(data)) > -1 ; )
////						out.write( data, 0, read);
////					out.flush();
////					fin.close();
////					
////				} catch (FileNotFoundException e) {
////					pout.println("404 Object not found");
////				}
////				
////				
////			} else {
////				pout.println("400 Bad Request");
////			}
////			
////			client.close();
//		
//		} catch (IOException e) {
//			System.out.println("I/O error " + e);
//		}
//	}
//}